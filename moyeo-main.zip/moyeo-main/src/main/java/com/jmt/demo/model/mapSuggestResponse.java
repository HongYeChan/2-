package com.jmt.demo.model;


public class mapSuggestResponse {

	
}