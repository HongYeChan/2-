package com.jmt.demo.controller;

import com.jmt.demo.dao.MessageDAO;
import com.jmt.demo.model.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 이 컨트롤러는 특정 여행 계획과 관련된 메시지 API를 처리.
 * RESTful 서비스를 통해 여행 계획 ID에 따른 메시지를 조회할 수 있음
 */
@RestController
@RequestMapping("/api/messages")
public class MessageController {

    // MessageDAO를 주입받아 데이터베이스와의 상호작용에 사용
    @Autowired
    private MessageDAO messageDAO;

    /**
     * 특정 여행 계획 ID에 해당하는 메시지 목록을 조회
     *
     * @param planId 조회할 여행 계획의 ID
     * @return 해당 여행 계획에 속한 메시지 목록
     */
    @GetMapping("/plan/{planId}")
    public List<Message> getMessagesByPlanId(@PathVariable Long planId) {
        return messageDAO.findByPlanId(planId);
    }
}