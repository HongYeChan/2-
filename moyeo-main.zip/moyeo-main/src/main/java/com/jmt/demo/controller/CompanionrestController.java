package com.jmt.demo.controller;

import com.jmt.demo.dao.CompanionDAO;
import com.jmt.demo.dto.CompanionRequestDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 이 컨트롤러는 동행 요청 관련 API를 처리
 * RESTful 서비스를 제공하여 동행 요청의 조회 및 승인을 담당
 */
@RestController
@RequestMapping("/api/companions")
public class CompanionrestController {

    // CompanionDAO를 주입받아 데이터베이스와의 상호작용에 사용함
    @Autowired
    private CompanionDAO companionDao;

    /**
     * 특정 사용자의 동행 요청 목록을 조회
     *
     * @param userId 조회할 사용자의 ID
     * @return 해당 사용자의 동행 요청 목록
     */
    @GetMapping("/requests")
    public List<CompanionRequestDto> getCompanionRequests(@RequestParam Long userId) {
        return companionDao.findRequestsByUserId(userId);
    }

    /**
     * 동행 요청을 승인함
     *
     * @param data 승인할 동행 요청의 ID를 포함하는 데이터 맵
     * @return 승인 결과를 담은 응답 객체
     */
    @PostMapping("/approve")
    public Map<String, Object> approveRequest(@RequestBody Map<String, Long> data) {
        Long companionId = data.get("companionId");
        boolean success = companionDao.approveRequest(companionId);
        Map<String, Object> response = new HashMap<>();
        response.put("success", success);
        return response;
    }
}
