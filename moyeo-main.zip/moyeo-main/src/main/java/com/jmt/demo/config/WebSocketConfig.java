package com.jmt.demo.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

/**
 * 이 설정 클래스는 Spring 애플리케이션에서 WebSocket 메시징을 설정하는 데 사용됨
 * WebSocket 메시지 브로커를 활성화하고 메시징을 위한 STOMP 프로토콜을 구성
 */
@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    /**
     * 메시지 브로커 옵션을 구성
     *
     * @param config 메시지 브로커를 구성하기 위한 MessageBrokerRegistry
     */
    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
        // 간단한 메모리 기반 메시지 브로커를 활성화. 목적지 접두사를 "/topic"으로 설정
        // "/topic"으로 시작하는 목적지를 가진 메시지는 메시지 브로커로 라우팅
        config.enableSimpleBroker("/topic");
        config.setApplicationDestinationPrefixes("/app");
    }

    /**
     * 클라이언트가 WebSocket 서버에 연결할 때 사용할 STOMP 엔드포인트를 등록
     *
     * @param registry STOMP 엔드포인트를 등록하기 위한 StompEndpointRegistry
     */
    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        // 클라이언트가 WebSocket 서버에 연결할 때 사용할 "/chat" 엔드포인트를 등록
        // SockJS를 사용하여 WebSocket을 지원하지 않는 브라우저에서도 연결할 수 있도록 함
        registry.addEndpoint("/chat").withSockJS();
    }
}